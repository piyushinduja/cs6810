#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <map>
#include <bitset>
#include <cstring>
#include <sstream>
#include "pin.H"
using std::cerr;
using std::endl;
using std::ios;
using std::ofstream;
using std::string;
using std::bitset;
using std::vector;
using std::reverse;
using std::map;
using std::to_string;

// Simulation will stop when this number of instructions have been executed
//
#define STOP_INSTR_NUM 1000000000 // 1b instrs

// Simulator heartbeat rate
//
#define SIMULATOR_HEARTBEAT_INSTR_NUM 100000000 // 100m instrs

/* Base branch predictor class */
// You are highly recommended to follow this design when implementing your branch predictors
//
class BranchPredictorInterface {
public:
  //This function returns a prediction for a branch instruction with address branchPC
  virtual bool getPrediction(ADDRINT branchPC) = 0;
  
  //This function updates branch predictor's history with outcome of branch instruction with address branchPC
  virtual void train(ADDRINT branchPC, bool branchWasTaken) = 0;
};

// This is a class which implements always taken branch predictor
class AlwaysTakenBranchPredictor : public BranchPredictorInterface {
public:
  AlwaysTakenBranchPredictor(UINT64 numberOfEntries) {}; //no entries here: always taken branch predictor is the simplest predictor
	virtual bool getPrediction(ADDRINT branchPC) {
		return true; // predict taken
	}
	virtual void train(ADDRINT branchPC, bool branchWasTaken) {} //nothing to do here: always taken branch predictor does not have history
};

class TournamentBranchPredictor : public BranchPredictorInterface {
public:
  UINT64 GHR = 0;
  map<string, int> GBP_PHT;
  map<string, int> LBP_PHT;
  map<string, string> LHR;
  map<string, int> meta_PHT;
  int entries = 0;
  TournamentBranchPredictor(UINT64 numberOfEntries) {

    entries = numberOfEntries;

    string lbp_bits;
    if(numberOfEntries==128)
      lbp_bits = "0000000";
    else if(numberOfEntries==1024)
      lbp_bits = "0000000000";
    else if(numberOfEntries==4096)
      lbp_bits = "000000000000";
    for (int i = 0; i < 128; i++){
        string x = std::bitset<7>(i).to_string();
        LHR[x] = lbp_bits;
    }

    if (numberOfEntries==128){
      for (int i = 0; i < 128; i++){
        string x = std::bitset<7>(i).to_string();
        LBP_PHT[x] = 3;
        GBP_PHT[x] = 3;
        meta_PHT[x] = 3;
      }
    } else if (numberOfEntries==1024){
      for (int i = 0; i < 1024; i++){
        string x = std::bitset<10>(i).to_string();
        LBP_PHT[x] = 3;
        GBP_PHT[x] = 3;
        meta_PHT[x] = 3;
      }
    } else if (numberOfEntries==4096){
      for (int i = 0; i < 4096; i++){
        string x = std::bitset<12>(i).to_string();
        LBP_PHT[x] = 3;
        GBP_PHT[x] = 3;
        meta_PHT[x] = 3;
      }
    }
    
  }; 
	virtual bool getPrediction(ADDRINT branchPC) {
    bool gshare_pred = true;
    bool local_pred = true;
    int meta_pred = 3;
		UINT64 gshare_s1 = 0;
    if(entries==128){
      gshare_s1 = branchPC & 0x7F;
      GHR = GHR & 0x7F;
    }else if(entries==1024){
      gshare_s1 = branchPC & 0x1FF;
      GHR = GHR & 0x3FF;
    }else if(entries==4096){
      gshare_s1 = branchPC & 0x7FF;
      GHR = GHR & 0xFFF;
    }
    string ghr_pht_entry = std::to_string(GHR ^ gshare_s1);
    if(GBP_PHT[ghr_pht_entry]==3 || GBP_PHT[ghr_pht_entry]==2) gshare_pred=true;
    else gshare_pred=false;

    string bin = std::bitset<30>(branchPC).to_string();
    reverse(bin.begin(), bin.end());
	  string s = bin.substr(0, 7);
	  reverse(s.begin(), s.end());
    int local_pht_pred = LBP_PHT[LHR[s]];
    if(local_pht_pred==3 || local_pht_pred==2) local_pred=true;
    else local_pred=false;

    string bin1 = "";
    string s2 = "";
    if(entries==128){
      bin1 = std::bitset<30>(branchPC).to_string();
      reverse(bin1.begin(), bin1.end());
	    s2 = bin1.substr(0, 7);
	    reverse(s2.begin(), s2.end());
    }else if(entries==1024){
      bin1 = std::bitset<30>(branchPC).to_string();
      reverse(bin1.begin(), bin1.end());
	    s2 = bin1.substr(0, 10);
	    reverse(s2.begin(), s2.end());
    }else{
      bin1 = std::bitset<30>(branchPC).to_string();
      reverse(bin1.begin(), bin1.end());
	    s2 = bin1.substr(0, 12);
	    reverse(s2.begin(), s2.end());
    }
    meta_pred = meta_PHT[s2];

    if(meta_pred==3 || meta_pred==2){
      return local_pred;
    }else{
      return gshare_pred;
    }
	}
	virtual void train(ADDRINT branchPC, bool branchWasTaken) {
    UINT64 gshare_s1 = 0;
    string s2 = "";
    string bin1 = "";
    if(entries==128){
      gshare_s1 = branchPC & 0x7F;
      GHR = GHR & 0x7F;
      bin1 = std::bitset<30>(branchPC).to_string();
      reverse(bin1.begin(), bin1.end());
	    s2 = bin1.substr(0, 7);
	    reverse(s2.begin(), s2.end());
    }else if(entries==1024){
      gshare_s1 = branchPC & 0x1FF;
      GHR = GHR & 0x3FF;
      bin1 = std::bitset<30>(branchPC).to_string();
      reverse(bin1.begin(), bin1.end());
	    s2 = bin1.substr(0, 10);
	    reverse(s2.begin(), s2.end());
    }else if(entries==4096){
      gshare_s1 = branchPC & 0x7FF;
      GHR = GHR & 0xFFF;
      bin1 = std::bitset<30>(branchPC).to_string();
      reverse(bin1.begin(), bin1.end());
	    s2 = bin1.substr(0, 12);
	    reverse(s2.begin(), s2.end());
    }

    string value = std::to_string(GHR ^ gshare_s1);
    int gshare_pred = GBP_PHT[value];

    string bin = std::bitset<30>(branchPC).to_string();
    reverse(bin.begin(), bin.end());
	  string s = bin.substr(0, 7);
	  reverse(s.begin(), s.end());
    int local_pred = LBP_PHT[LHR[s]];

    int meta_pred = meta_PHT[s2];

    if(branchWasTaken){
        if(gshare_pred==2) GBP_PHT[value] = 3;
        else if(gshare_pred==1) GBP_PHT[value] = 2;
        else if(gshare_pred==0) GBP_PHT[value] = 1;

        if(local_pred==2) LBP_PHT[LHR[s]] = 3;
        else if(local_pred==1) LBP_PHT[LHR[s]] = 2;
        else if(local_pred==0) LBP_PHT[LHR[s]] = 1;

        GHR = GHR & 0x3F;
        GHR = GHR << 1;
        GHR = GHR | 1;

        string main = LHR[s];
        string sub = main.substr(1, main.length()-1);
        sub += '1';
        LHR[s] = sub;

        if(meta_pred==3){
          if(local_pred==3 || local_pred==2){
            meta_PHT[s2] = 3;
          }else{
            meta_PHT[s2] = 2;
          }
        }else if(meta_pred==2){
          if(local_pred==3 || local_pred==2){
            meta_PHT[s2] = 3;
          }else{
            meta_PHT[s2] = 1;
          }
        }else if(meta_pred==1){
          if(gshare_pred==3 || gshare_pred==2){
            meta_PHT[s2] = 2;
          }else{
            meta_PHT[s2] = 0;
          }
        }else{
          if(gshare_pred==3 || gshare_pred==2){
            meta_PHT[s2] = 1;
          }else{
            meta_PHT[s2] = 0;
          }
        }

      }else{
        if(gshare_pred==3) GBP_PHT[value] = 2;
        else if(gshare_pred==2) GBP_PHT[value] = 1;
        else if(gshare_pred==1) GBP_PHT[value] = 0;

        if(local_pred==3) LBP_PHT[LHR[s]] = 2;
        else if(local_pred==2) LBP_PHT[LHR[s]] = 1;
        else if(local_pred==1) LBP_PHT[LHR[s]] = 0;

        GHR = GHR & 0x3F;
        GHR = GHR << 1;
        GHR = GHR | 0;

        string main = LHR[s];
        string sub = main.substr(1, main.length()-1);
        sub += '0';
        LHR[s] = sub;

        if(meta_pred==3){
          if(local_pred==0 || local_pred==1){
            meta_PHT[s2] = 3;
          }else{
            meta_PHT[s2] = 2;
          }
        }else if(meta_pred==2){
          if(local_pred==0 || local_pred==1){
            meta_PHT[s2] = 3;
          }else{
            meta_PHT[s2] = 1;
          }
        }else if(meta_pred==1){
          if(gshare_pred==0 || gshare_pred==1){
            meta_PHT[s2] = 2;
          }else{
            meta_PHT[s2] = 0;
          }
        }else{
          if(gshare_pred==0 || gshare_pred==1){
            meta_PHT[s2] = 1;
          }else{
            meta_PHT[s2] = 0;
          }
        }
      }
  } 
};

class GshareBranchPredictor : public BranchPredictorInterface {
public:
  UINT64 GHR = 0;
  map<string, int> PHT;
  int bits = 0;
  GshareBranchPredictor(UINT64 numberOfEntries) {

    if (numberOfEntries==128){
      bits = 128;
      for (int i = 0; i < 128; i++){
        string x = std::bitset<7>(i).to_string();
        PHT[x] = 3;
      }
    } else if (numberOfEntries==1024){
      bits = 1024;
      for (int i = 0; i < 1024; i++){
        string x = std::bitset<10>(i).to_string();
        PHT[x] = 3;
      }
    } else if (numberOfEntries==4096){
      bits = 4096;
      for (int i = 0; i < 4096; i++){
        string x = std::bitset<12>(i).to_string();
        PHT[x] = 3;
      }
    }
  }; 
	virtual bool getPrediction(ADDRINT branchPC) {
    UINT64 s1 = 0;
    if(bits==128){
      s1 = branchPC & 0x7F;
      GHR = GHR & 0x7F;
    }else if(bits==1024){
      s1 = branchPC & 0x1FF;
      GHR = GHR & 0x3FF;
    }else if(bits==4096){
      s1 = branchPC & 0x7FF;
      GHR = GHR & 0xFFF;
    }
    
    string pht_entry = std::to_string(GHR ^ s1);

    if(PHT[pht_entry]==3 || PHT[pht_entry]==2) return true;
    else return false;
	}
	virtual void train(ADDRINT branchPC, bool branchWasTaken) {
    UINT64 s1 = 0;
    if(bits==128){
      s1 = branchPC & 0x7F;
      GHR = GHR & 0x7F;
    }else if(bits==1024){
      s1 = branchPC & 0x1FF;
      GHR = GHR & 0x3FF;
    }else if(bits==4096){
      s1 = branchPC & 0x7FF;
      GHR = GHR & 0xFFF;
    }

    string value = std::to_string(GHR ^ s1);
    int pred_bin = PHT[value];

    if(branchWasTaken){
        if(pred_bin==2) PHT[value] = 3;
        else if(pred_bin==1) PHT[value] = 2;
        else if(pred_bin==0) PHT[value] = 1;

        GHR = GHR & 0x3F;
        GHR = GHR << 1;
        GHR = GHR | 1;
      }else{
        if(pred_bin==3) PHT[value] = 2;
        else if(pred_bin==2) PHT[value] = 1;
        else if(pred_bin==1) PHT[value] = 0;

        GHR = GHR & 0x3F;
        GHR = GHR << 1;
        GHR = GHR | 0;
      }
  }
};

class LocalBranchPredictor : public BranchPredictorInterface {
public:
  map<string, string> LHR;
  map<string, int> PHT;
  LocalBranchPredictor(UINT64 numberOfEntries){
    string bits;
    
    if (numberOfEntries==128){
      bits = "0000000";
      for (int i = 0; i < 128; i++){
        string x = std::bitset<7>(i).to_string();
        PHT[x] = 3;
      }
    } else if (numberOfEntries==1024){
      bits = "0000000000";
      for (int i = 0; i < 1024; i++){
        string x = std::bitset<10>(i).to_string();
        PHT[x] = 3;
      }
    } else if (numberOfEntries==4096){
      bits = "000000000000";
      for (int i = 0; i < 4096; i++){
        string x = std::bitset<12>(i).to_string();
        PHT[x] = 3;
      }
    }

    for (int i = 0; i < 128; i++){
        string x = std::bitset<7>(i).to_string();
        LHR[x] = bits;
    }
    
  };
  virtual bool getPrediction(ADDRINT branchPC){
    string bin = std::bitset<30>(branchPC).to_string();
    reverse(bin.begin(), bin.end());
	  string s = bin.substr(0, 7);
	  reverse(s.begin(), s.end());

    int pht_pred = PHT[LHR[s]];

    if(pht_pred==3 || pht_pred==2) return true;
    else return false;
  }

  virtual void train(ADDRINT branchPC, bool branchWasTaken){
    string bin = std::bitset<30>(branchPC).to_string();
    reverse(bin.begin(), bin.end());
	  string s = bin.substr(0, 7);
	  reverse(s.begin(), s.end());

    int pred_bin = PHT[LHR[s]];

    if(branchWasTaken){
        if(pred_bin==2) PHT[LHR[s]] = 3;
        else if(pred_bin==1) PHT[LHR[s]] = 2;
        else if(pred_bin==0) PHT[LHR[s]] = 1;

        string main = LHR[s];
        string sub = main.substr(1, main.length()-1);
        sub += '1';
        LHR[s] = sub;
      }else{
        if(pred_bin==3) PHT[LHR[s]] = 2;
        else if(pred_bin==2) PHT[LHR[s]] = 1;
        else if(pred_bin==1) PHT[LHR[s]] = 0;

        string main = LHR[s];
        string sub = main.substr(1, main.length()-1);
        sub += '0';
        LHR[s] = sub;
    }
  }
};

//------------------------------------------------------------------------------
//##############################################################################
/*
 * Insert your changes below here...
 *
 * Put your branch predictor implementation here
 *
 * For example:
 * class LocalBranchPredictor : public BranchPredictorInterface {
 *
 *   ***put private members for Local branch predictor here
 *
 *   public:
 *	   virtual bool getPrediction(ADDRINT branchPC) {
 *	  	 ***put your implementation here
 *	   }
 *	   virtual void train(ADDRINT branchPC, bool branchWasTaken) {
 *	     ***put your implementation here
 *	   }
 * }
 *
 * You also need to create an object of branch predictor class in main()
 * (i.e. at line 193 in the original unmodified version of this file).
 */
//##############################################################################
//------------------------------------------------------------------------------

ofstream OutFile;
BranchPredictorInterface *branchPredictor;

// Define the command line arguments that Pin should accept for this tool
//
KNOB<string> KnobOutputFile(KNOB_MODE_WRITEONCE, "pintool",
    "o", "BP_stats.out", "specify output file name");
KNOB<UINT64> KnobNumberOfEntriesInBranchPredictor(KNOB_MODE_WRITEONCE, "pintool",
    "num_BP_entries", "1024", "specify number of entries in a branch predictor");
KNOB<string> KnobBranchPredictorType(KNOB_MODE_WRITEONCE, "pintool",
    "BP_type", "always_taken", "specify type of branch predictor to be used");

// The running counts of branches, predictions and instructions are kept here
//
static UINT64 iCount                          = 0;
static UINT64 correctPredictionCount          = 0;
static UINT64 conditionalBranchesCount        = 0;
static UINT64 takenBranchesCount              = 0;
static UINT64 notTakenBranchesCount           = 0;
static UINT64 predictedTakenBranchesCount     = 0;
static UINT64 predictedNotTakenBranchesCount  = 0;

VOID docount() {
  // Update instruction counter
  iCount++;
  // Print this message every SIMULATOR_HEARTBEAT_INSTR_NUM executed
  if (iCount % SIMULATOR_HEARTBEAT_INSTR_NUM == 0) {
    std::cerr << "Executed " << iCount << " instructions." << endl;
  }
  // Release control of application if STOP_INSTR_NUM instructions have been executed
  if (iCount == STOP_INSTR_NUM) {
    PIN_Detach();
  }
}



VOID TerminateSimulationHandler(VOID *v) {
  OutFile.setf(ios::showbase);
  // At the end of a simulation, print counters to a file
  OutFile << "Prediction accuracy:\t"            << (double)correctPredictionCount / (double)conditionalBranchesCount << endl
          << "Number of conditional branches:\t" << conditionalBranchesCount                                      << endl
          << "Number of correct predictions:\t"  << correctPredictionCount                                        << endl
          << "Number of taken branches:\t"       << takenBranchesCount                                            << endl
          << "Number of non-taken branches:\t"   << notTakenBranchesCount                                         << endl
          ;
  OutFile.close();

  std::cerr << endl << "PIN has been detached at iCount = " << STOP_INSTR_NUM << endl;
  std::cerr << endl << "Simulation has reached its target point. Terminate simulation." << endl;
  std::cerr << "Prediction accuracy:\t" << (double)correctPredictionCount / (double)conditionalBranchesCount << endl;
  std::exit(EXIT_SUCCESS);
}

//
VOID Fini(int code, VOID * v)
{
  TerminateSimulationHandler(v);
}

// This function is called before every conditional branch is executed
//
static VOID AtConditionalBranch(ADDRINT branchPC, BOOL branchWasTaken) {
  /*
	 * This is the place where the predictor is queried for a prediction and trained
	 */

  // Step 1: make a prediction for the current branch PC
  //
	bool wasPredictedTaken = branchPredictor->getPrediction(branchPC);
  
  // Step 2: train the predictor by passing it the actual branch outcome
  //
	branchPredictor->train(branchPC, branchWasTaken);

  // Count the number of conditional branches executed
  conditionalBranchesCount++;
  
  // Count the number of conditional branches predicted taken and not-taken
  if (wasPredictedTaken) {
    predictedTakenBranchesCount++;
  } else {
    predictedNotTakenBranchesCount++;
  }

  // Count the number of conditional branches actually taken and not-taken
  if (branchWasTaken) {
    takenBranchesCount++;
  } else {
    notTakenBranchesCount++;
  }

  // Count the number of correct predictions
	if (wasPredictedTaken == branchWasTaken)
    correctPredictionCount++;
}

// Pin calls this function every time a new instruction is encountered
// Its purpose is to instrument the benchmark binary so that when 
// instructions are executed there is a callback to count the number of
// executed instructions, and a callback for every conditional branch
// instruction that calls our branch prediction simulator (with the PC
// value and the branch outcome).
//
VOID Instruction(INS ins, VOID *v) {
  // Insert a call before every instruction that simply counts instructions executed
  INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR)docount, IARG_END);

  // Insert a call before every conditional branch
  if ( INS_IsBranch(ins) && INS_HasFallThrough(ins) ) {
    INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR)AtConditionalBranch, IARG_INST_PTR, IARG_BRANCH_TAKEN, IARG_END);
  }
}

// Print Help Message
INT32 Usage() {
  cerr << "This tool simulates different types of branch predictors" << endl;
  cerr << endl << KNOB_BASE::StringKnobSummary() << endl;
  return -1;
}

int main(int argc, char * argv[]) {
  // Initialize pin
  if (PIN_Init(argc, argv)) return Usage();

  // Create a branch predictor object of requested type
  if (KnobBranchPredictorType.Value() == "always_taken") {
    std::cerr << "Using always taken BP" << std::endl;
    branchPredictor = new AlwaysTakenBranchPredictor(KnobNumberOfEntriesInBranchPredictor.Value());
  }
//------------------------------------------------------------------------------
//##############################################################################
/*
 * Insert your changes below here...
 *
 * In the following cascading if-statements instantiate branch predictor objects
 * using the classes that you have implemented for each of the three types of
 * predictor.
 *
 * The choice of predictor, and the number of entries in its prediction table
 * can be obtained from the command line arguments of this Pin tool using:
 *
 *  KnobNumberOfEntriesInBranchPredictor.Value() 
 *    returns the integer value specified by tool option "-num_BP_entries".
 *
 *  KnobBranchPredictorType.Value() 
 *    returns the value specified by tool option "-BP_type".
 *    The argument of tool option "-BP_type" must be one of the strings: 
 *        "always_taken",  "local",  "gshare",  "tournament"
 *
 *  Please DO NOT CHANGE these strings - they will be used for testing your code
 */
//##############################################################################
//------------------------------------------------------------------------------
  else if (KnobBranchPredictorType.Value() == "local") {
  	 std::cerr << "Using Local BP." << std::endl;
/* Uncomment when you have implemented a Local branch predictor */
     std::cerr << "Entries: " << KnobNumberOfEntriesInBranchPredictor.Value();
     branchPredictor = new LocalBranchPredictor(KnobNumberOfEntriesInBranchPredictor.Value());
  }
  else if (KnobBranchPredictorType.Value() == "gshare") {
  	 std::cerr << "Using Gshare BP."<< std::endl;
/* Uncomment when you have implemented a Gshare branch predictor */
    branchPredictor = new GshareBranchPredictor(KnobNumberOfEntriesInBranchPredictor.Value());
  }
  else if (KnobBranchPredictorType.Value() == "tournament") {
  	 std::cerr << "Using Tournament BP." << std::endl;
/* Uncomment when you have implemented a Tournament branch predictor */
    branchPredictor = new TournamentBranchPredictor(KnobNumberOfEntriesInBranchPredictor.Value());
  }
  else {
    std::cerr << "Error: No such type of branch predictor. Simulation will be terminated." << std::endl;
    std::exit(EXIT_FAILURE);
  }

  std::cerr << "The simulation will run " << STOP_INSTR_NUM << " instructions." << std::endl;

  OutFile.open(KnobOutputFile.Value().c_str());

  // Pin calls Instruction() when encountering each new instruction executed
  INS_AddInstrumentFunction(Instruction, 0);

  // Function to be called if the program finishes before it completes 10b instructions
  PIN_AddFiniFunction(Fini, 0);

  // Callback functions to invoke before Pin releases control of the application
  PIN_AddDetachFunction(TerminateSimulationHandler, 0);

  // Start the benchmark program. This call never returns...
  PIN_StartProgram();

  return 0;
}
